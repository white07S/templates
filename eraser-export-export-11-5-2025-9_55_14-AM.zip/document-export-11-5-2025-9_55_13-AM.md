# Azure-based Agentic Workflow Platform Architecture



