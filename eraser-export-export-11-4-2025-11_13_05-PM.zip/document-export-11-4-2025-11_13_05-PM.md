# Azure LLM Platform Architecture



